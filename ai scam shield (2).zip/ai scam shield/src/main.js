function analyze() {
  const sms = document.getElementById("sms").value;

  const data = {
    score: 92,
    risk: "HIGH",
    type: "Lottery Scam",
    steps: [
      "SMS Understanding Done",
      "Fraud Pattern Detected",
      "Decision: BLOCK Sender",
      "Running Simulation"
    ],
    logs: [
      "Sender Blocked",
      "Alert Sent",
      "Scam Report Generated"
    ],
    before: "Sender Active / Unknown Risk",
    after: "Sender Blocked / Threat Neutralized / User Protected"
  };

  document.getElementById("result").innerHTML = `
    <h3>Risk Score: ${data.score}</h3>
    <h4>Risk Level: ${data.risk}</h4>
    <p>Scam Type: ${data.type}</p>

    <h4>Insight Extraction (Agent 1)</h4>
    ${data.steps.map(s => `<p>${s}</p>`).join("")}

    <h4>Action Execution (Agent 3)</h4>
    ${data.logs.map(l => `<p>${l}</p>`).join("")}

    <h4>Before → After</h4>
    <p>Before: ${data.before}</p>
    <p>After: ${data.after}</p>
  `;
}

window.analyze = analyze;